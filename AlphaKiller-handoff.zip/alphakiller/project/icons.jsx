// Minimal icon set — sharp, 16px viewBox, 1.5 stroke
const Icon = ({ name, size = 14 }) => {
  const common = { width: size, height: size, viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", strokeWidth: 1.4, strokeLinecap: "round", strokeLinejoin: "round" };
  const paths = {
    folder: <><path d="M1.5 4.5 A1 1 0 0 1 2.5 3.5 H6 L7.5 5 H13.5 A1 1 0 0 1 14.5 6 V12 A1 1 0 0 1 13.5 13 H2.5 A1 1 0 0 1 1.5 12 Z"/></>,
    file:  <><path d="M3.5 1.5 H9 L12.5 5 V14.5 H3.5 Z"/><path d="M9 1.5 V5 H12.5"/></>,
    save:  <><path d="M2.5 2.5 H11 L13.5 5 V13.5 H2.5 Z"/><path d="M5 2.5 V6 H10 V2.5"/><path d="M5 9 H11"/></>,
    undo:  <><path d="M4.5 6.5 L2 4 L4.5 1.5"/><path d="M2 4 H9.5 A4.5 4.5 0 0 1 9.5 13 H7"/></>,
    redo:  <><path d="M11.5 6.5 L14 4 L11.5 1.5"/><path d="M14 4 H6.5 A4.5 4.5 0 0 0 6.5 13 H9"/></>,
    chevD: <><path d="M4 6 L8 10 L12 6"/></>,
    chevR: <><path d="M6 4 L10 8 L6 12"/></>,
    chevL: <><path d="M10 4 L6 8 L10 12"/></>,
    x:     <><path d="M4 4 L12 12 M12 4 L4 12"/></>,
    plus:  <><path d="M8 3 V13 M3 8 H13"/></>,
    minus: <><path d="M3 8 H13"/></>,
    dots:  <><circle cx="3.5" cy="8" r=".8" fill="currentColor" stroke="none"/><circle cx="8" cy="8" r=".8" fill="currentColor" stroke="none"/><circle cx="12.5" cy="8" r=".8" fill="currentColor" stroke="none"/></>,
    drag:  <><circle cx="5.5" cy="4" r=".7" fill="currentColor" stroke="none"/><circle cx="10.5" cy="4" r=".7" fill="currentColor" stroke="none"/><circle cx="5.5" cy="8" r=".7" fill="currentColor" stroke="none"/><circle cx="10.5" cy="8" r=".7" fill="currentColor" stroke="none"/><circle cx="5.5" cy="12" r=".7" fill="currentColor" stroke="none"/><circle cx="10.5" cy="12" r=".7" fill="currentColor" stroke="none"/></>,
    eye:   <><path d="M1.5 8 Q4.5 3 8 3 T14.5 8 Q11.5 13 8 13 T1.5 8 Z"/><circle cx="8" cy="8" r="2"/></>,
    split: <><rect x="2" y="3" width="12" height="10" rx="1"/><path d="M8 3 V13" strokeDasharray="1.5 1.5"/></>,
    splitV:<><rect x="2" y="3" width="12" height="10" rx="1"/><path d="M2 8 H14" strokeDasharray="1.5 1.5"/></>,
    mask:  <><circle cx="8" cy="8" r="5.5"/><path d="M8 2.5 A5.5 5.5 0 0 1 8 13.5 Z" fill="currentColor" stroke="none"/></>,
    diff:  <><rect x="2" y="4" width="8" height="8" rx="1"/><rect x="6" y="6" width="8" height="8" rx="1" fill="currentColor" fillOpacity=".15"/></>,
    zoomIn:<><circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5 L14 14 M7 4.5 V9.5 M4.5 7 H9.5"/></>,
    zoomOut:<><circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5 L14 14 M4.5 7 H9.5"/></>,
    fit:   <><path d="M3 6 V3 H6 M13 6 V3 H10 M3 10 V13 H6 M13 10 V13 H10"/></>,
    hand:  <><path d="M5 9 V4.5 A1 1 0 0 1 7 4.5 V8 M7 7 V3.5 A1 1 0 0 1 9 3.5 V8 M9 7.5 V4.5 A1 1 0 0 1 11 4.5 V9 M11 7 A1 1 0 0 1 13 7 V10 A4 4 0 0 1 9 14 H7 A4 4 0 0 1 3 10 V8"/></>,
    export:<><path d="M8 10 V2 M5 5 L8 2 L11 5"/><path d="M2.5 10 V13.5 H13.5 V10"/></>,
    settings:<><circle cx="8" cy="8" r="2"/><path d="M8 2 L8 4 M8 12 L8 14 M14 8 L12 8 M4 8 L2 8 M12.2 3.8 L10.8 5.2 M5.2 10.8 L3.8 12.2 M12.2 12.2 L10.8 10.8 M5.2 5.2 L3.8 3.8"/></>,
    play:  <><path d="M5 3.5 V12.5 L13 8 Z" fill="currentColor"/></>,
    pause: <><rect x="4.5" y="3.5" width="2.5" height="9" fill="currentColor" stroke="none"/><rect x="9" y="3.5" width="2.5" height="9" fill="currentColor" stroke="none"/></>,
    check: <><path d="M3 8.5 L6.5 12 L13 4.5"/></>,
    alert: <><path d="M8 2 L14.5 13.5 H1.5 Z"/><path d="M8 6 V9.5 M8 11.5 V12"/></>,
    star:  <><path d="M8 2 L10 6.5 L14.5 7 L11 10.5 L12 14.5 L8 12.5 L4 14.5 L5 10.5 L1.5 7 L6 6.5 Z"/></>,
    copy:  <><rect x="4.5" y="4.5" width="9" height="9" rx="1"/><path d="M2.5 11 V3 A1 1 0 0 1 3.5 2 H10"/></>,
    trash: <><path d="M3 4.5 H13 M6 4.5 V2.5 H10 V4.5 M4.5 4.5 L5 13.5 H11 L11.5 4.5"/></>,
    rename:<><path d="M9.5 3 L13 6.5 L6 13.5 H2.5 V10 Z"/><path d="M8 4.5 L11.5 8"/></>,
    search:<><circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5 L14 14"/></>,
    pipette:<><path d="M9 4 L12 7 M10.5 2.5 L13.5 5.5 M2 14 L5 11 M5 11 L11 5 L11 5 L14 8 L8 14 Z"/></>,
    grid:  <><rect x="2" y="2" width="5" height="5" rx=".5"/><rect x="9" y="2" width="5" height="5" rx=".5"/><rect x="2" y="9" width="5" height="5" rx=".5"/><rect x="9" y="9" width="5" height="5" rx=".5"/></>,
    down:  <><path d="M8 3 V13 M4 9 L8 13 L12 9"/></>,
    importt:<><path d="M8 2 V10 M5 7 L8 10 L11 7"/><path d="M2.5 10 V13.5 H13.5 V10"/></>,
  };
  return <svg {...common}>{paths[name] || null}</svg>;
};

// Demo artifact image — a "speaker" UI icon rendered onto an SVG image with
// intentionally fringed/semi-transparent edges. Passes showFringe/clean state.
const DemoIcon = ({ clean = false, showMask = false, showDiff = false }) => {
  if (showMask) {
    // Pure alpha mask view — white where opaque, black where transparent
    return (
      <svg viewBox="0 0 120 120" className="demo-icon">
        <defs>
          <filter id="aa-mask">
            <feMorphology operator="dilate" radius={clean ? "0.3" : "1.2"} />
          </filter>
        </defs>
        <g fill="#fff" filter="url(#aa-mask)">
          <path d="M30 48 L52 48 L72 32 L72 88 L52 72 L30 72 Z"/>
          <path d="M82 48 Q92 60 82 72" stroke="#fff" strokeWidth="4" fill="none" strokeLinecap="round"/>
          <path d="M90 42 Q104 60 90 78" stroke="#fff" strokeWidth="4" fill="none" strokeLinecap="round"/>
        </g>
      </svg>
    );
  }
  if (showDiff) {
    // Difference view — red/magenta where cleanup touched pixels
    return (
      <svg viewBox="0 0 120 120" className="demo-icon">
        <g>
          <path d="M30 48 L52 48 L72 32 L72 88 L52 72 L30 72 Z" fill="#0a0a0a"/>
          {/* Diff — pixels that changed */}
          <g fill="oklch(0.7 0.22 20)" opacity="0.9">
            <path d="M30 47 L52 47 L72 31 L72 33 L52 49 L30 49 Z"/>
            <path d="M30 71 L52 71 L72 87 L72 89 L52 73 L30 73 Z"/>
            <path d="M29 48 L31 48 L31 72 L29 72 Z"/>
          </g>
          <path d="M82 48 Q92 60 82 72" stroke="oklch(0.7 0.22 20)" strokeWidth="2" fill="none" strokeLinecap="round" opacity=".9"/>
        </g>
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 120 120" className="demo-icon">
      <defs>
        {/* Dirty: white matte halo + soft edge bleed */}
        <filter id="dirty-edge" x="-10%" y="-10%" width="120%" height="120%">
          <feGaussianBlur in="SourceAlpha" stdDeviation="1.4" result="blur"/>
          <feFlood floodColor="#ffffff" floodOpacity="0.85"/>
          <feComposite in2="blur" operator="in" result="halo"/>
          <feMerge>
            <feMergeNode in="halo"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
        <filter id="dirty-jag">
          <feTurbulence baseFrequency="0.9" numOctaves="1" seed="3"/>
          <feDisplacementMap in="SourceGraphic" scale="1.4"/>
        </filter>
        <linearGradient id="speaker-grad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="oklch(0.74 0.17 148)"/>
          <stop offset="1" stopColor="oklch(0.58 0.18 155)"/>
        </linearGradient>
      </defs>
      <g filter={clean ? null : "url(#dirty-edge)"}>
        <g filter={clean ? null : "url(#dirty-jag)"}>
          <path
            d="M30 48 L52 48 L72 32 L72 88 L52 72 L30 72 Z"
            fill="url(#speaker-grad)"
            stroke={clean ? "none" : "rgba(255,255,255,.4)"}
            strokeWidth={clean ? 0 : 0.6}
          />
          <path d="M82 48 Q92 60 82 72" stroke="url(#speaker-grad)" strokeWidth="5" fill="none" strokeLinecap="round"/>
          <path d="M90 42 Q104 60 90 78" stroke="url(#speaker-grad)" strokeWidth="5" fill="none" strokeLinecap="round"/>
        </g>
      </g>
    </svg>
  );
};

Object.assign(window, { Icon, DemoIcon });
