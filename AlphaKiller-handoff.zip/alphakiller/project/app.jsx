const { useState, useEffect, useRef, useCallback, useMemo } = React;

/* ───────── Tweak defaults ───────── */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "screen": "editor",
  "tool": "defringe",
  "compare": "split-h",
  "showModal": false,
  "showToast": false
}/*EDITMODE-END*/;

/* ───────── Constants ───────── */
const SCREENS = ["editor", "empty", "batch", "presets"];
const TOOLS = [
  { id: "threshold", label: "Alpha Threshold", short: "Threshold" },
  { id: "defringe",  label: "Defringe",         short: "Defringe" },
  { id: "bleed",     label: "Color Bleed",      short: "Color Bleed" },
  { id: "hardening", label: "Alpha Hardening",  short: "Hardening" },
];

const PRESETS = [
  { id: "gentle",   name: "Gentle Edge Cleanup", desc: "Light defringe for UI icons",      builtin: true },
  { id: "hard",     name: "Hard Alpha Cutout",   desc: "Threshold at 128, no softness",    builtin: true },
  { id: "whiteMat", name: "White Matte Defringe",desc: "Remove white halo from exports",   builtin: true },
  { id: "blackMat", name: "Black Matte Defringe",desc: "Remove black halo from exports",   builtin: true },
  { id: "sprite",   name: "Sprite Edge Padding", desc: "Bleed colors into transparency",   builtin: true },
  { id: "icon",     name: "Icon Cleanup",        desc: "Hardening + light defringe",       builtin: true },
  { id: "user1",    name: "My Avatar Workflow",  desc: "Custom — last used 2d ago",        builtin: false },
  { id: "user2",    name: "Hero PNGs",           desc: "Custom — last used yesterday",     builtin: false },
];

const RECENT = [
  { n: "ui-speaker-icon.png",    d: "120×120",  size: "4.2 KB",  active: true },
  { n: "hero-cutout@2x.png",     d: "1024×768", size: "186 KB" },
  { n: "sprite-atlas.png",       d: "512×512",  size: "84 KB" },
  { n: "logo-mark-export.webp",  d: "256×256",  size: "12 KB" },
  { n: "tile_grass_01.png",      d: "64×64",    size: "2.1 KB" },
];

const BATCH = [
  { n: "ui-speaker-icon.png", d: "120×120",  s: "4.2 KB",  st: "complete" },
  { n: "ui-heart-icon.png",   d: "120×120",  s: "3.8 KB",  st: "complete" },
  { n: "ui-star-icon.png",    d: "120×120",  s: "4.1 KB",  st: "complete" },
  { n: "hero-cutout@2x.png",  d: "1024×768", s: "186 KB",  st: "processing", pct: 62 },
  { n: "sprite-atlas.png",    d: "512×512",  s: "84 KB",   st: "pending" },
  { n: "logo-mark.webp",      d: "256×256",  s: "12 KB",   st: "pending" },
  { n: "tile_grass_01.png",   d: "64×64",    s: "2.1 KB",  st: "warning", msg: "Fully opaque" },
  { n: "corrupt.png",         d: "—",        s: "0 B",     st: "error",   msg: "Cannot decode" },
  { n: "tile_sand_02.png",    d: "64×64",    s: "2.0 KB",  st: "pending" },
  { n: "tile_water_01.png",   d: "64×64",    s: "1.9 KB",  st: "pending" },
  { n: "avatar-ring.png",     d: "256×256",  s: "18 KB",   st: "pending" },
  { n: "button-export.png",   d: "220×48",   s: "5.6 KB",  st: "pending" },
];

const BG_COLORS = ["checker", "black", "white", "gray", "custom"];

/* ───────── App ───────── */
function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Canvas state
  const [bg, setBg] = useState("checker");
  const [customBg, setCustomBg] = useState("oklch(0.55 0.2 280)");
  const [customPickerOpen, setCustomPickerOpen] = useState(false);
  const [zoom, setZoom] = useState(2);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [panning, setPanning] = useState(false);
  const panRef = useRef(null);

  // Split
  const [split, setSplit] = useState(50); // percent
  const splitDragRef = useRef(null);
  const canvasViewRef = useRef(null);

  // Inspector
  const [activeTool, setActiveTool] = useState(t.tool);
  useEffect(() => setActiveTool(t.tool), [t.tool]);

  const [threshold, setThreshold] = useState(128);
  const [softness, setSoftness] = useState(8);
  const [preserveRGB, setPreserveRGB] = useState(true);
  const [showAffected, setShowAffected] = useState(false);

  const [matteColor, setMatteColor] = useState("#FFFFFF");
  const [strength, setStrength] = useState(72);
  const [edgeRadius, setEdgeRadius] = useState(2);
  const [protectSat, setProtectSat] = useState(true);

  const [bleedRadius, setBleedRadius] = useState(4);
  const [iterations, setIterations] = useState(3);
  const [affectTransparent, setAffectTransparent] = useState(true);

  const [hardStrength, setHardStrength] = useState(60);
  const [midpoint, setMidpoint] = useState(50);
  const [curve, setCurve] = useState("smooth");

  // Preset
  const [presetId, setPresetId] = useState("gentle");
  const [selectedPreset, setSelectedPreset] = useState("whiteMat");

  // Cursor tracking
  const [cursor, setCursor] = useState({ x: 56, y: 48, r: 174, g: 180, b: 190, a: 0.72 });

  const [compareMode, setCompareMode] = useState(t.compare);
  useEffect(() => setCompareMode(t.compare), [t.compare]);

  const [showExport, setShowExport] = useState(t.showModal);
  useEffect(() => setShowExport(t.showModal), [t.showModal]);

  /* Pan handling */
  const onPanStart = (e) => {
    if (e.button !== 0 && e.button !== 1) return;
    if (e.target.closest('.split-handle')) return;
    setPanning(true);
    panRef.current = { sx: e.clientX, sy: e.clientY, px: pan.x, py: pan.y };
    e.preventDefault();
  };
  useEffect(() => {
    if (!panning) return;
    const onMove = (e) => {
      if (!panRef.current) return;
      setPan({
        x: panRef.current.px + (e.clientX - panRef.current.sx),
        y: panRef.current.py + (e.clientY - panRef.current.sy),
      });
    };
    const onUp = () => { setPanning(false); panRef.current = null; };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
  }, [panning]);

  /* Wheel zoom */
  const onWheel = (e) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    setZoom(z => Math.max(0.25, Math.min(16, z * delta)));
  };

  /* Split drag */
  const onSplitStart = (e) => {
    e.stopPropagation();
    splitDragRef.current = true;
  };
  useEffect(() => {
    const onMove = (e) => {
      if (!splitDragRef.current) return;
      const rect = canvasViewRef.current?.getBoundingClientRect();
      if (!rect) return;
      // We need position relative to the stage, not the viewport, for accuracy
      // Simpler: find the img-frame element
      const frame = canvasViewRef.current.querySelector('.img-frame');
      if (!frame) return;
      const fr = frame.getBoundingClientRect();
      const p = ((e.clientX - fr.left) / fr.width) * 100;
      setSplit(Math.max(4, Math.min(96, p)));
    };
    const onUp = () => { splitDragRef.current = false; };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
  }, []);

  /* Track mouse on canvas for status bar */
  const onCanvasMouseMove = (e) => {
    const frame = canvasViewRef.current?.querySelector('.img-frame');
    if (!frame) return;
    const fr = frame.getBoundingClientRect();
    const x = Math.floor(((e.clientX - fr.left) / fr.width) * 120);
    const y = Math.floor(((e.clientY - fr.top) / fr.height) * 120);
    if (x < 0 || x > 119 || y < 0 || y > 119) return;
    // Fake RGBA based on pos
    const inside = (x > 22 && x < 78 && y > 30 && y < 90);
    setCursor({
      x, y,
      r: inside ? 92 : 174,
      g: inside ? 178 : 180,
      b: inside ? 130 : 190,
      a: inside ? 1.0 : Math.max(0, Math.min(1, (40 - Math.abs(56 - y)) / 30))
    });
  };

  const zoomPct = Math.round(zoom * 100);

  return (
    <div className="app" style={t.screen !== 'editor' ? { gridTemplateRows: '32px 40px 1fr 24px' } : {}}>

      <TitleBar screen={t.screen} setScreen={(s) => setTweak('screen', s)} />
      <Toolbar
        compareMode={compareMode}
        setCompareMode={(m) => { setCompareMode(m); setTweak('compare', m); }}
        onExport={() => setTweak('showModal', true)}
        zoom={zoomPct}
      />

      <div className={`main ${t.screen !== 'editor' ? 'hide-center' : ''}`}>
        {t.screen === 'editor' && <>
          <LeftPanel />
          <CenterCanvas
            bg={bg} setBg={setBg}
            customBg={customBg} setCustomBg={setCustomBg}
            customPickerOpen={customPickerOpen} setCustomPickerOpen={setCustomPickerOpen}
            zoom={zoom} setZoom={setZoom}
            pan={pan} panning={panning}
            onPanStart={onPanStart} onWheel={onWheel}
            split={split} onSplitStart={onSplitStart}
            compareMode={compareMode}
            canvasViewRef={canvasViewRef}
            onCanvasMouseMove={onCanvasMouseMove}
          />
          <RightInspector
            activeTool={activeTool}
            setActiveTool={(tool) => { setActiveTool(tool); setTweak('tool', tool); }}
            threshold={threshold} setThreshold={setThreshold}
            softness={softness} setSoftness={setSoftness}
            preserveRGB={preserveRGB} setPreserveRGB={setPreserveRGB}
            showAffected={showAffected} setShowAffected={setShowAffected}
            matteColor={matteColor} setMatteColor={setMatteColor}
            strength={strength} setStrength={setStrength}
            edgeRadius={edgeRadius} setEdgeRadius={setEdgeRadius}
            protectSat={protectSat} setProtectSat={setProtectSat}
            bleedRadius={bleedRadius} setBleedRadius={setBleedRadius}
            iterations={iterations} setIterations={setIterations}
            affectTransparent={affectTransparent} setAffectTransparent={setAffectTransparent}
            hardStrength={hardStrength} setHardStrength={setHardStrength}
            midpoint={midpoint} setMidpoint={setMidpoint}
            curve={curve} setCurve={setCurve}
            presetId={presetId} setPresetId={setPresetId}
            onExport={() => setTweak('showModal', true)}
          />
        </>}

        {t.screen === 'empty' && <EmptyState />}
        {t.screen === 'batch' && <BatchScreen />}
        {t.screen === 'presets' && <PresetsScreen selectedPreset={selectedPreset} setSelectedPreset={setSelectedPreset} />}
      </div>

      <StatusBar
        screen={t.screen}
        zoom={zoomPct}
        cursor={cursor}
        bg={bg}
      />

      {t.showModal && (
        <ExportModal
          onClose={() => setTweak('showModal', false)}
          onDone={() => { setTweak('showModal', false); setTweak('showToast', true); setTimeout(() => setTweak('showToast', false), 3000); }}
        />
      )}
      {t.showToast && <Toast onClose={() => setTweak('showToast', false)} />}

      <TweaksPanel>
        <TweakSection label="Screen" />
        <TweakRadio label="View" value={t.screen}
          options={["editor", "empty", "batch", "presets"]}
          onChange={(v) => setTweak('screen', v)} />
        <TweakSection label="Editor" />
        <TweakRadio label="Tool" value={t.tool}
          options={["threshold", "defringe", "bleed", "hardening"]}
          onChange={(v) => setTweak('tool', v)} />
        <TweakRadio label="Compare" value={t.compare}
          options={["split-h", "split-v", "orig", "proc", "mask", "diff"]}
          onChange={(v) => setTweak('compare', v)} />
        <TweakSection label="Dialogs" />
        <TweakToggle label="Export dialog" value={t.showModal}
          onChange={(v) => setTweak('showModal', v)} />
      </TweaksPanel>
    </div>
  );
}

/* ───────── Title Bar ───────── */
function TitleBar({ screen, setScreen }) {
  return (
    <div className="title-bar">
      <div className="traffic">
        <button className="t-close" aria-label="close"></button>
        <button className="t-min" aria-label="minimize"></button>
        <button className="t-max" aria-label="maximize"></button>
      </div>
      <div className="menus">
        {["File", "Edit", "View", "Tools", "Help"].map(m => (
          <button key={m} className="menu-item">{m}</button>
        ))}
      </div>
      <div className="title">
        <b>AlphaKiller</b>
        <span className="dot">·</span>
        {screen === 'editor' && <>ui-speaker-icon.png <span className="dot">·</span> <span style={{color:'var(--accent)'}}>Edited</span></>}
        {screen === 'batch' && <>Batch · 12 files</>}
        {screen === 'presets' && <>Presets</>}
        {screen === 'empty' && <>No image</>}
      </div>
      <div className="right-bits">
        {SCREENS.map(s => (
          <button key={s} className={`menu-item ${screen === s ? 'active':''}`} onClick={() => setScreen(s)}>
            {s[0].toUpperCase()+s.slice(1)}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ───────── Toolbar ───────── */
function Toolbar({ compareMode, setCompareMode, onExport, zoom }) {
  return (
    <div className="toolbar">
      <div className="tb-group">
        <button className="tb-btn" title="Open (⌘O)"><Icon name="folder"/></button>
        <button className="tb-btn" title="Save"><Icon name="save"/></button>
      </div>
      <div className="tb-group">
        <button className="tb-btn" title="Undo (⌘Z)"><Icon name="undo"/></button>
        <button className="tb-btn" title="Redo (⌘⇧Z)"><Icon name="redo"/></button>
      </div>
      <div className="tb-group">
        <button className="tb-btn" title="Zoom out"><Icon name="zoomOut"/></button>
        <button className="tb-btn" title="Fit (⌘0)"><Icon name="fit"/></button>
        <button className="tb-btn" title="Zoom in"><Icon name="zoomIn"/></button>
        <span style={{padding:'0 6px',fontFamily:'var(--font-mono)',fontSize:11,color:'var(--text-2)',minWidth:44,textAlign:'center'}}>{zoom}%</span>
      </div>
      <div className="tb-group">
        <div className="segmented" role="tablist" aria-label="Comparison mode">
          <button className={compareMode==='proc'?'active':''} onClick={()=>setCompareMode('proc')} title="Processed">
            <Icon name="eye" size={12}/>After
          </button>
          <button className={compareMode==='orig'?'active':''} onClick={()=>setCompareMode('orig')} title="Original">
            Before
          </button>
          <button className={compareMode==='split-h'?'active':''} onClick={()=>setCompareMode('split-h')} title="Split (S)">
            <Icon name="split" size={12}/>Split
          </button>
          <button className={compareMode==='mask'?'active':''} onClick={()=>setCompareMode('mask')} title="Alpha mask (A)">
            <Icon name="mask" size={12}/>Mask
          </button>
          <button className={compareMode==='diff'?'active':''} onClick={()=>setCompareMode('diff')} title="Difference">
            <Icon name="diff" size={12}/>Diff
          </button>
        </div>
      </div>
      <div className="tb-spacer"></div>
      <div className="tb-group" style={{borderRight:0, gap:6}}>
        <button className="tb-label" title="Settings"><Icon name="settings"/></button>
        <button className="tb-label primary" onClick={onExport}>
          <Icon name="export" size={12}/> Export
        </button>
      </div>
    </div>
  );
}

/* ───────── Left Panel ───────── */
function LeftPanel() {
  return (
    <div className="panel left">
      <div className="panel-hd">
        <span>Source</span>
        <div className="hd-actions">
          <button title="Import"><Icon name="importt" size={12}/></button>
        </div>
      </div>
      <div className="panel-body">
        <div className="file-card">
          <div className="file-thumb">
            <DemoIcon clean={false}/>
          </div>
          <div className="file-name">ui-speaker-icon.png</div>
          <div className="file-meta">
            <span className="k">Size</span><span className="v">120 × 120</span>
            <span className="k">Bytes</span><span className="v">4,214</span>
            <span className="k">Color</span><span className="v">RGBA / 8 bpc</span>
            <span className="k">Alpha</span><span className="v"><span className="badge"><span className="dt"></span>Transparent</span></span>
          </div>
        </div>
        <div className="recent-hd">Recent</div>
        {RECENT.map((r, i) => (
          <div key={i} className={`recent-row ${r.active?'active':''}`}>
            <div className="recent-thumb">PNG</div>
            <div className="recent-info">
              <div className="n">{r.n}</div>
              <div className="m">{r.d} · {r.size}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ───────── Canvas ───────── */
function CenterCanvas({
  bg, setBg, customBg, setCustomBg, customPickerOpen, setCustomPickerOpen,
  zoom, pan, panning, onPanStart, onWheel,
  split, onSplitStart, compareMode, canvasViewRef, onCanvasMouseMove
}) {
  const showPixelGrid = zoom > 4;
  const frameBg = bg === 'custom' ? { "--custom-bg": customBg } : {};

  const showSplit = compareMode.startsWith('split');
  const vertical = compareMode === 'split-v';

  return (
    <div className="canvas-wrap"
      onWheel={onWheel}>
      <div className="canvas-toolbar">
        <button className="tb-btn" title="Pan (H)"><Icon name="hand"/></button>
        <button className="tb-btn active" title="Pointer"><Icon name="pipette"/></button>
        <div className="divider"/>
        <div className="bg-swatches" role="group" aria-label="Preview background">
          {BG_COLORS.map(c => (
            <button key={c}
              className={`swatch ${c} ${bg === c ? 'active' : ''}`}
              style={c === 'custom' ? { background: customBg } : {}}
              onClick={() => { setBg(c); if (c === 'custom') setCustomPickerOpen(v => !v); else setCustomPickerOpen(false); }}
              title={c}
            />
          ))}
          {customPickerOpen && (
            <div className="popover">
              {[
                "oklch(0.55 0.2 280)","oklch(0.55 0.2 25)","oklch(0.55 0.2 145)","oklch(0.65 0.18 80)",
                "oklch(0.45 0.2 330)","oklch(0.65 0.18 200)","oklch(0.3 0.05 260)","#ff00ff",
                "#00ffff","#ffff00","#ff6b35","#7928ca"
              ].map((c, i) => (
                <button key={i} className="c-sw" style={{background:c}}
                  onClick={() => { setCustomBg(c); setBg('custom'); setCustomPickerOpen(false); }}/>
              ))}
            </div>
          )}
        </div>
        <div className="divider"/>
        <button className="tb-btn" title="Toggle grid"><Icon name="grid"/></button>
      </div>

      <div
        ref={canvasViewRef}
        className={`canvas-view ${panning?'panning':''}`}
        onMouseDown={onPanStart}
        onMouseMove={onCanvasMouseMove}
      >
        <div className="canvas-stage"
          style={{ transform: `translate(calc(-50% + ${pan.x}px), calc(-50% + ${pan.y}px)) scale(${zoom})` }}>
          <div className={`img-frame ${bg}`} style={{
            ...frameBg,
            "--split": showSplit ? `${split}%` : "100%"
          }}>
            {/* Render modes */}
            {compareMode === 'proc' && <div className="img-layer"><DemoIcon clean/></div>}
            {compareMode === 'orig' && <div className="img-layer"><DemoIcon/></div>}
            {compareMode === 'split-h' && <>
              <div className="img-layer left-half"><DemoIcon/></div>
              <div className="img-layer right-half"><DemoIcon clean/></div>
              <div className="split-label left">BEFORE</div>
              <div className="split-label right">AFTER</div>
              <div className="split-handle" onMouseDown={onSplitStart}></div>
              <div className="split-grip">
                <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.2">
                  <path d="M3 2 L1 5 L3 8 M7 2 L9 5 L7 8"/>
                </svg>
              </div>
            </>}
            {compareMode === 'split-v' && <>
              <div className="img-layer" style={{clipPath:`polygon(0 0, 100% 0, 100% ${split}%, 0 ${split}%)`}}><DemoIcon/></div>
              <div className="img-layer" style={{clipPath:`polygon(0 ${split}%, 100% ${split}%, 100% 100%, 0 100%)`}}><DemoIcon clean/></div>
            </>}
            {compareMode === 'mask' && (
              <div className="img-layer" style={{background:'#000'}}><DemoIcon showMask/></div>
            )}
            {compareMode === 'diff' && (
              <div className="img-layer" style={{background:'#0a0a0a'}}><DemoIcon showDiff/></div>
            )}
            {showPixelGrid && <div className="pixel-grid" style={{opacity:.4}}></div>}
          </div>
        </div>
      </div>

      <div className="canvas-zoom">
        <button className="tb-btn" title="Zoom out"><Icon name="minus"/></button>
        <span className="zoom-val">{Math.round(zoom*100)}%</span>
        <button className="tb-btn" title="Zoom in"><Icon name="plus"/></button>
        <div className="divider" style={{margin:'0 2px'}}/>
        <button className="tb-btn" title="Fit (⌘0)"><Icon name="fit"/></button>
      </div>
    </div>
  );
}

/* ───────── Right Inspector ───────── */
function RightInspector(p) {
  return (
    <div className="panel right">
      <div className="panel-hd">
        <span>Inspector</span>
        <div className="hd-actions">
          <button title="Reset all"><Icon name="undo" size={12}/></button>
          <button title="More"><Icon name="dots" size={12}/></button>
        </div>
      </div>
      <div className="panel-body">
        {/* Preset */}
        <div className="inspector-section">
          <div className="sect-hd"><span>Preset</span></div>
          <div className="preset-row">
            <div className="preset-dropdown">
              <div className="fake-select">
                <span className="dot"/>
                {PRESETS.find(pr => pr.id === p.presetId)?.name || 'Custom'}
              </div>
              <span className="chev"><Icon name="chevD" size={10}/></span>
            </div>
            <button className="icon-sq-btn" title="Save as preset"><Icon name="save"/></button>
            <button className="icon-sq-btn" title="More"><Icon name="dots"/></button>
          </div>
        </div>

        {/* Cleanup stack */}
        <div className="inspector-section">
          <div className="sect-hd">
            <span>Cleanup Stack</span>
            <span style={{fontFamily:'var(--font-mono)',color:'var(--text-4)',textTransform:'none',letterSpacing:0}}>
              {[p.activeTool].length} active
            </span>
          </div>
          {TOOLS.map(tool => (
            <CleanupRow key={tool.id}
              tool={tool}
              active={p.activeTool === tool.id}
              enabled={tool.id === 'defringe' || tool.id === p.activeTool}
              onClick={() => p.setActiveTool(tool.id)}
            />
          ))}
        </div>

        {/* Tool-specific */}
        {p.activeTool === 'threshold' && <ThresholdControls {...p}/>}
        {p.activeTool === 'defringe' &&  <DefringeControls {...p}/>}
        {p.activeTool === 'bleed' &&     <BleedControls {...p}/>}
        {p.activeTool === 'hardening' && <HardeningControls {...p}/>}

        {/* Export */}
        <div className="inspector-section" style={{borderBottom:0}}>
          <div className="sect-hd"><span>Export</span></div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6, marginBottom:8}}>
            <button className="btn">PNG</button>
            <button className="btn ghost">WebP</button>
          </div>
          <div className="sub-toggle">
            <span>Preserve metadata</span>
            <Toggle value={true}/>
          </div>
          <div className="sub-toggle" style={{marginBottom:10}}>
            <span>Add <code style={{fontFamily:'var(--font-mono)',fontSize:10.5,color:'var(--text)'}}>-cleaned</code> suffix</span>
            <Toggle value={true}/>
          </div>
          <button className="btn primary full" onClick={p.onExport}>
            <Icon name="export" size={12}/> Export Image…
          </button>
        </div>
      </div>
    </div>
  );
}

function CleanupRow({ tool, active, enabled, onClick }) {
  return (
    <div className={`cleanup-row ${active?'active':''}`} onClick={onClick}>
      <span className="c-drag"><Icon name="drag" size={10}/></span>
      <Toggle value={enabled} onChange={()=>{}}/>
      <span className="c-name">{tool.short}</span>
      <span className="c-meta">{active ? 'editing' : enabled ? 'on' : ''}</span>
    </div>
  );
}

function Toggle({ value, onChange }) {
  return (
    <button
      className={`toggle ${value?'on':''}`}
      onClick={(e) => { e.stopPropagation(); onChange && onChange(!value); }}
      role="switch" aria-checked={value}
    />
  );
}

function Slider({ label, value, onChange, min = 0, max = 100, step = 1, unit = "" }) {
  const pct = ((value - min) / (max - min)) * 100;
  const trackRef = useRef(null);
  const draggingRef = useRef(false);
  const onDown = (e) => { draggingRef.current = true; move(e); e.preventDefault(); };
  const move = (e) => {
    if (!trackRef.current) return;
    const r = trackRef.current.getBoundingClientRect();
    const p = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    const v = min + p * (max - min);
    onChange(Math.round(v/step)*step);
  };
  useEffect(() => {
    const mv = (e) => draggingRef.current && move(e);
    const up = () => draggingRef.current = false;
    window.addEventListener('mousemove', mv);
    window.addEventListener('mouseup', up);
    return () => { window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); };
  }, []);
  return (
    <div className="field">
      <span className="flabel">{label}</span>
      <div className="slider-track" ref={trackRef} onMouseDown={onDown}>
        <div className="slider-rail"/>
        <div className="slider-fill" style={{width:`${pct}%`}}/>
        <div className="slider-knob" style={{left:`${pct}%`}}/>
      </div>
      <input className="fnum" type="text" value={`${value}${unit}`} readOnly/>
    </div>
  );
}

function Stepper({ label, value, onChange, min = 0, max = 100 }) {
  return (
    <div className="field" style={{gridTemplateColumns:'90px 1fr auto'}}>
      <span className="flabel">{label}</span>
      <div/>
      <div style={{display:'flex',gap:2,alignItems:'center'}}>
        <button className="icon-sq-btn" style={{width:22,height:22}}
          onClick={() => onChange(Math.max(min, value-1))}>
          <Icon name="minus" size={10}/>
        </button>
        <input className="fnum" value={value} readOnly style={{width:40, textAlign:'center'}}/>
        <button className="icon-sq-btn" style={{width:22,height:22}}
          onClick={() => onChange(Math.min(max, value+1))}>
          <Icon name="plus" size={10}/>
        </button>
      </div>
    </div>
  );
}

function ColorField({ label, value, onChange }) {
  return (
    <div className="field">
      <span className="flabel">{label}</span>
      <div/>
      <div className="color-field" style={{width:120}}>
        <span className="cs-sw" style={{background:value}}/>
        <span className="cs-val">{value.toUpperCase()}</span>
        <span className="cs-eye"><Icon name="pipette" size={10}/></span>
      </div>
    </div>
  );
}

function ThresholdControls(p) {
  return (
    <div className="inspector-section">
      <div className="sect-hd"><span>Alpha Threshold</span><span className="chev"><Icon name="chevD" size={10}/></span></div>
      <Slider label="Threshold" value={p.threshold} onChange={p.setThreshold} min={0} max={255}/>
      <Slider label="Edge softness" value={p.softness} onChange={p.setSoftness} min={0} max={32} unit="px"/>
      <div className="sub-toggle">
        <span>Preserve transparent RGB</span>
        <Toggle value={p.preserveRGB} onChange={p.setPreserveRGB}/>
      </div>
      <div className="sub-toggle">
        <span>Preview affected pixels</span>
        <Toggle value={p.showAffected} onChange={p.setShowAffected}/>
      </div>
    </div>
  );
}
function DefringeControls(p) {
  return (
    <div className="inspector-section">
      <div className="sect-hd"><span>Defringe</span><span className="chev"><Icon name="chevD" size={10}/></span></div>
      <ColorField label="Matte color" value={p.matteColor}/>
      <button className="btn full" style={{marginBottom:10}}>
        <Icon name="pipette" size={12}/> Auto-detect matte
        <span style={{marginLeft:'auto',fontFamily:'var(--font-mono)',fontSize:10,color:'var(--accent)'}}>98%</span>
      </button>
      <Slider label="Strength"   value={p.strength}   onChange={p.setStrength}   min={0} max={100} unit="%"/>
      <Slider label="Edge radius" value={p.edgeRadius} onChange={p.setEdgeRadius} min={0} max={16}  unit="px"/>
      <div className="sub-toggle">
        <span>Protect saturated colors</span>
        <Toggle value={p.protectSat} onChange={p.setProtectSat}/>
      </div>
      <div className="sub-toggle">
        <span>Preview fringe map</span>
        <Toggle value={false} onChange={()=>{}}/>
      </div>
    </div>
  );
}
function BleedControls(p) {
  return (
    <div className="inspector-section">
      <div className="sect-hd"><span>Color Bleed</span><span className="chev"><Icon name="chevD" size={10}/></span></div>
      <Slider label="Radius" value={p.bleedRadius} onChange={p.setBleedRadius} min={0} max={32} unit="px"/>
      <Stepper label="Iterations" value={p.iterations} onChange={p.setIterations} min={1} max={16}/>
      <div className="sub-toggle">
        <span>Affect transparent pixels</span>
        <Toggle value={p.affectTransparent} onChange={p.setAffectTransparent}/>
      </div>
      <div className="sub-toggle">
        <span>Preserve alpha</span>
        <Toggle value={true} onChange={()=>{}}/>
      </div>
    </div>
  );
}
function HardeningControls(p) {
  return (
    <div className="inspector-section">
      <div className="sect-hd"><span>Alpha Hardening</span><span className="chev"><Icon name="chevD" size={10}/></span></div>
      <Slider label="Strength" value={p.hardStrength} onChange={p.setHardStrength} min={0} max={100} unit="%"/>
      <Slider label="Midpoint" value={p.midpoint}     onChange={p.setMidpoint}     min={0} max={100} unit="%"/>
      <div className="field">
        <span className="flabel">Curve</span>
        <div className="seg-sm" style={{gridColumn:'2 / span 2'}}>
          {["linear","smooth","aggressive"].map(c => (
            <button key={c} className={p.curve===c?'active':''} onClick={()=>p.setCurve(c)}>{c}</button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ───────── Status Bar ───────── */
function StatusBar({ screen, zoom, cursor, bg }) {
  if (screen !== 'editor') {
    return (
      <div className="status-bar">
        <div className="status-item dot-accent"><span className="sv">Ready</span></div>
        <div className="status-item"><span className="sk">Screen</span><span className="sv">{screen}</span></div>
        <div style={{flex:1}}/>
        <div className="status-item"><span className="sk">v0.4.2-beta</span></div>
      </div>
    );
  }
  const hex = '#' + [cursor.r, cursor.g, cursor.b].map(v => v.toString(16).padStart(2,'0')).join('').toUpperCase();
  return (
    <div className="status-bar">
      <div className="status-item dot-accent"><span className="sv">Ready</span></div>
      <div className="status-item"><span className="sk">Zoom</span><span className="sv">{zoom}%</span></div>
      <div className="status-item"><span className="sk">Size</span><span className="sv">120 × 120</span></div>
      <div className="status-item"><span className="sk">Pos</span><span className="sv">{cursor.x.toString().padStart(3)}, {cursor.y.toString().padStart(3)}</span></div>
      <div className="status-item">
        <span className="sk">RGBA</span>
        <span className="sv" style={{display:'inline-flex',alignItems:'center',gap:6}}>
          <span style={{width:10,height:10,borderRadius:2,background:hex,border:'1px solid rgba(255,255,255,.1)'}}/>
          {cursor.r.toString().padStart(3)} {cursor.g.toString().padStart(3)} {cursor.b.toString().padStart(3)} {cursor.a.toFixed(2)}
        </span>
      </div>
      <div className="status-item"><span className="sk">α</span><span className="sv">{Math.round(cursor.a*255).toString().padStart(3)}</span></div>
      <div style={{flex:1}}/>
      <div className="status-item"><span className="sk">Bg</span><span className="sv">{bg}</span></div>
      <div className="status-item"><span className="sk">Semi-α</span><span className="sv">14.2%</span></div>
      <div className="status-item"><span className="sk">Matte</span><span className="sv">#FFFFFF</span></div>
    </div>
  );
}

/* ───────── Empty State ───────── */
function EmptyState() {
  return (
    <div style={{gridColumn:'1 / -1', position:'relative', background:'var(--bg-canvas)'}}>
      <div className="empty-center">
        <div className="empty-drop">
          <div className="logo">
            <svg width="30" height="30" viewBox="0 0 30 30" fill="none">
              <circle cx="15" cy="15" r="11" stroke="oklch(0.74 0.17 148)" strokeWidth="1.5"/>
              <path d="M9 15 Q15 9 21 15 Q15 21 9 15 Z" fill="oklch(0.74 0.17 148)" fillOpacity=".25" stroke="oklch(0.74 0.17 148)" strokeWidth="1.2"/>
              <path d="M6 6 L24 24" stroke="oklch(0.74 0.17 148)" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
          </div>
          <h1>Drop an image to begin</h1>
          <div className="sub">Or open a file or folder to start cleaning alpha artifacts.</div>
          <div className="actions">
            <button className="btn primary">Open Image</button>
            <button className="btn">Open Folder…</button>
          </div>
          <div className="formats">
            PNG · WebP &nbsp;&nbsp;<span className="kbd">⌘O</span> open &nbsp; <span className="kbd">⌘⇧O</span> batch
          </div>
        </div>
      </div>
    </div>
  );
}

/* ───────── Batch Screen ───────── */
function BatchScreen() {
  const complete = BATCH.filter(b => b.st === 'complete').length;
  const processing = BATCH.filter(b => b.st === 'processing').length;
  const errors = BATCH.filter(b => b.st === 'error').length;
  const pending = BATCH.filter(b => b.st === 'pending').length;
  return (
    <div style={{gridColumn:'1 / -1', position:'relative'}}>
      <div className="batch-wrap">
        <div className="batch-toolbar">
          <span className="title">Batch Processing</span>
          <span className="sub">Preset: <b style={{color:'var(--text)'}}>White Matte Defringe</b></span>
          <div className="batch-progress-bar"><div className="fill"/></div>
          <span style={{color:'var(--text-2)',fontFamily:'var(--font-mono)',fontSize:11}}>
            {complete}/{BATCH.length} · 2m 14s left
          </span>
          <div style={{flex:1}}/>
          <button className="btn"><Icon name="plus" size={12}/>Add files</button>
          <button className="btn">Change preset…</button>
          <button className="btn warn">Cancel</button>
        </div>
        <div className="batch-list">
          <div className="batch-hd">
            <span></span>
            <span>File</span>
            <span>Dimensions</span>
            <span>Size</span>
            <span>Status</span>
            <span></span>
            <span></span>
          </div>
          {BATCH.map((b, i) => (
            <div key={i} className="batch-row">
              <div className="b-thumb">PNG</div>
              <div className="b-name">{b.n}</div>
              <div className="b-dims">{b.d}</div>
              <div className="b-size">{b.s}</div>
              <div className={`b-status status-${b.st}`}>
                <span className="d"/>
                {b.st === 'processing' ? `Processing · ${b.pct}%` :
                 b.st === 'complete' ? 'Complete' :
                 b.st === 'warning' ? (b.msg || 'Warning') :
                 b.st === 'error' ? (b.msg || 'Error') :
                 'Pending'}
              </div>
              <button className="icon-sq-btn" title="Preview"><Icon name="eye" size={11}/></button>
              <button className="icon-sq-btn" title="Remove"><Icon name="x" size={11}/></button>
            </div>
          ))}
        </div>
        <div className="batch-footer">
          <div className="stats">
            <span>Complete <span className="n">{complete}</span></span>
            <span>Processing <span className="n">{processing}</span></span>
            <span>Pending <span className="n">{pending}</span></span>
            <span style={{color:errors?'var(--err)':'var(--text-3)'}}>Errors <span className="n">{errors}</span></span>
          </div>
          <div style={{flex:1}}/>
          <span style={{color:'var(--text-3)',fontSize:11.5}}>
            Output → <span style={{fontFamily:'var(--font-mono)', color:'var(--text-2)'}}>~/Desktop/cleaned/</span>
          </span>
          <button className="btn">Change…</button>
          <button className="btn primary">
            <Icon name="pause" size={12}/>Pause
          </button>
        </div>
      </div>
    </div>
  );
}

/* ───────── Presets Screen ───────── */
function PresetsScreen({ selectedPreset, setSelectedPreset }) {
  const preset = PRESETS.find(p => p.id === selectedPreset);
  const builtins = PRESETS.filter(p => p.builtin);
  const users = PRESETS.filter(p => !p.builtin);
  return (
    <div style={{gridColumn:'1 / -1', position:'relative'}}>
      <div className="presets-wrap">
        <div className="presets-list">
          <div className="ph"><span>Built-in</span></div>
          {builtins.map(p => (
            <div key={p.id} className={`preset-item ${selectedPreset===p.id?'active':''}`} onClick={()=>setSelectedPreset(p.id)}>
              <div className="pn">{p.name}<span className="builtin-tag">BUILTIN</span></div>
              <div className="pd">{p.desc}</div>
            </div>
          ))}
          <div className="ph" style={{marginTop:8}}>
            <span>User</span>
            <button className="icon-sq-btn" style={{width:18,height:18,background:'transparent',border:0}}>
              <Icon name="plus" size={11}/>
            </button>
          </div>
          {users.map(p => (
            <div key={p.id} className={`preset-item ${selectedPreset===p.id?'active':''}`} onClick={()=>setSelectedPreset(p.id)}>
              <div className="pn">{p.name}</div>
              <div className="pd">{p.desc}</div>
            </div>
          ))}
        </div>
        <div className="preset-detail">
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:16}}>
            <div>
              <h2>{preset?.name}</h2>
              <div className="desc">{preset?.desc}. Use this for asset exports where the source had a white background assumption.</div>
            </div>
            <div style={{display:'flex',gap:6}}>
              <button className="btn"><Icon name="copy" size={12}/>Duplicate</button>
              <button className="btn"><Icon name="rename" size={12}/>Rename</button>
              <button className="btn"><Icon name="export" size={12}/>Export JSON</button>
              <button className="btn warn"><Icon name="trash" size={12}/>Delete</button>
            </div>
          </div>
          <div className="preset-settings">
            <span className="sk">Cleanup stack</span>
            <span className="sv" style={{color:'var(--text-2)'}}>
              Defringe → Color Bleed → Alpha Hardening
            </span>
            <span className="sk">Matte color</span>
            <span className="sv" style={{display:'inline-flex',alignItems:'center',gap:8}}>
              <span style={{width:14,height:14,borderRadius:3,background:'#fff',border:'1px solid rgba(255,255,255,.15)'}}/>
              #FFFFFF
            </span>
            <span className="sk">Defringe strength</span><span className="sv">72%</span>
            <span className="sk">Edge radius</span><span className="sv">2 px</span>
            <span className="sk">Protect saturated</span><span className="sv">true</span>
            <span className="sk">Bleed radius</span><span className="sv">4 px</span>
            <span className="sk">Bleed iterations</span><span className="sv">3</span>
            <span className="sk">Hardening strength</span><span className="sv">60%</span>
            <span className="sk">Hardening midpoint</span><span className="sv">50%</span>
            <span className="sk">Hardening curve</span><span className="sv">smooth</span>
          </div>
          <div style={{marginTop:20, display:'flex',gap:8}}>
            <button className="btn primary"><Icon name="check" size={12}/>Apply to current image</button>
            <button className="btn"><Icon name="star" size={12}/>Set as default</button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ───────── Export Modal ───────── */
function ExportModal({ onClose, onDone }) {
  const [fmt, setFmt] = useState('png');
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-hd">
          <h3>Export Image</h3>
          <button className="tb-btn" onClick={onClose}><Icon name="x" size={12}/></button>
        </div>
        <div className="modal-body">
          <div className="modal-row">
            <span className="mlabel">Format</span>
            <div className="seg-sm" style={{maxWidth:180,height:26}}>
              <button className={fmt==='png'?'active':''} onClick={()=>setFmt('png')}>PNG</button>
              <button className={fmt==='webp'?'active':''} onClick={()=>setFmt('webp')}>WebP</button>
            </div>
          </div>
          <div className="modal-row">
            <span className="mlabel">Filename</span>
            <input type="text" defaultValue={`ui-speaker-icon-cleaned.${fmt}`}/>
          </div>
          <div className="modal-row">
            <span className="mlabel">Destination</span>
            <div style={{display:'flex',gap:6}}>
              <input type="text" defaultValue="~/Desktop/exports/" style={{flex:1}}/>
              <button className="btn">Choose…</button>
            </div>
          </div>
          <div className="modal-row">
            <span className="mlabel">If exists</span>
            <div className="seg-sm" style={{maxWidth:260,height:26}}>
              <button className="active">Add suffix</button>
              <button>Overwrite</button>
              <button>Skip</button>
            </div>
          </div>
          <div className="modal-row">
            <span className="mlabel">Preserve metadata</span>
            <div><Toggle value={true}/></div>
          </div>
        </div>
        <div className="modal-ft">
          <div className="left-info">120×120 · RGBA · ~3.8 KB</div>
          <div style={{display:'flex',gap:6}}>
            <button className="btn ghost" onClick={onClose}>Cancel</button>
            <button className="btn primary" onClick={onDone}>
              <Icon name="export" size={12}/>Export
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Toast({ onClose }) {
  return (
    <div className="toast">
      <div className="ti"><Icon name="check"/></div>
      <div>
        <div className="tt">Exported ui-speaker-icon-cleaned.png</div>
        <div className="td">3.8 KB · ~/Desktop/exports/</div>
      </div>
      <button className="tb-btn" onClick={onClose}><Icon name="x" size={11}/></button>
    </div>
  );
}

/* ───────── Mount ───────── */
ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
